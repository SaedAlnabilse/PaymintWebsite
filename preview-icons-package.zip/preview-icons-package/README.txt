Mintcom Icon Preview Package
============================

Open index.html in any modern browser.

This package includes the Bootstrap Icons stylesheet and webfont locally, so
the icons display without an internet connection. It is a review-only preview:
the Mintcom website itself has not been changed.

Files:
- index.html: the preview to share
- assets/: bundled icon stylesheet and font asset
